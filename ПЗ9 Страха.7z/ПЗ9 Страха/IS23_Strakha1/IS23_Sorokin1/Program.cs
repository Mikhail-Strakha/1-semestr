﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Введите сумму вклада: "); decimal initialAmount = Convert.ToDecimal(Console.ReadLine());
        Console.Write("Введите количество месяцев: ");
        int months = Convert.ToInt32(Console.ReadLine());
        decimal interestRate = 0.07m; 
        for (int i = 1; i <= months; i++)
        {
            initialAmount += initialAmount * interestRate;
            Console.WriteLine($"Месяц {i}: {initialAmount}");
        }
        Console.WriteLine($"Итоговая сумма вклада после {months} месяцев: {initialAmount}");
    }

}