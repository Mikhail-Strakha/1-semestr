﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Введите номер операции: 1.Сложение 2.Вычитание 3.Умножение");
        int operation = Convert.ToInt32(Console.ReadLine());
        switch (operation)
        {
            case 1:
                Console.WriteLine("Выбрана операция сложения");
                break;
            case 2:
                Console.WriteLine("Выбрана операция вычитания");
                break;
            case 3:
                Console.WriteLine("Выбрана операция умножения");
                break;
            default:
                Console.WriteLine("Операция неопределена");
                break;
        }
    }
}