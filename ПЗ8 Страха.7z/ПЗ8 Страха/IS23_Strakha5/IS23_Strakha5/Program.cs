﻿using System;
class BankDeposit
{
    static void Main(string[] args)
    {
        Console.Write("Введите сумму вклада: ");
        double deposit = double.Parse(Console.ReadLine());
        double interestRate;
        if (deposit < 100)
        {
            interestRate = 0.05;
        }
        else if (deposit >= 100 && deposit <= 200)
        {
            interestRate = 0.07;
        }
        else
        {
            interestRate = 0.10;
        }
        double interest = deposit * interestRate;
        double bonus = 15;
        double totalDeposit = deposit + interest + bonus;
        Console.WriteLine($"Сумма вклада с начисленными процентами и бонусом: {totalDeposit}");
    }
}