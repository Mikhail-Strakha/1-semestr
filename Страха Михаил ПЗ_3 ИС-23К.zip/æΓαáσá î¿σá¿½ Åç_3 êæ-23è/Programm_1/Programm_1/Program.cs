﻿// 01_01.cs - Первая программа
using static System.Console;
    class HelloUser
    {
        static void Main()
        {
            string name;
            Console.WriteLine("Введите ваше имя: ");
            name = Console.ReadLine();
            Console.WriteLine("Приветствую вас, " + name + "!");
            Console.WriteLine("для завершения сеанса нажмите ENTER.");
        ReadLine();

        }
    }
