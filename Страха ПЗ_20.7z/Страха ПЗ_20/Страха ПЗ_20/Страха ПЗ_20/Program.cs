﻿using System;

class Program
{
    static void Main()
    {
        int result = SumNumbers();
        Console.WriteLine(result);
    }

    static int SumNumbers()
    {
        int num = Convert.ToInt32(Console.ReadLine());

        if (num == 0)
        {
            return 0;
        }

        else
        {
            return num + SumNumbers();
        }
    }
}