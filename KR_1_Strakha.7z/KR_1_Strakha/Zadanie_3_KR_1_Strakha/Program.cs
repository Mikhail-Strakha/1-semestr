﻿using System;

class Program
{
    static void Main()
    {
        string input = Console.ReadLine();
        string[] parts = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        int n = int.Parse(parts[0]);
        int validCount = 0;

        for (int i = 1; i <= n; i++)
        {
            int number = int.Parse(parts[i]);

            if (number >= 100000 && number <= 999999)
            {
                if ((number & 7) == 0)
                {
                    validCount++;
                }
            }
        }

        Console.WriteLine(validCount);
    }
}