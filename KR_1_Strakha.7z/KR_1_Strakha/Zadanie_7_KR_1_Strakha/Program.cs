﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main(string[] args)
    {
        string[] input = Console.ReadLine().Split();
        int t = int.Parse(input[0]);
        int v = int.Parse(input[1]);

        string[] input2 = Console.ReadLine().Split();
        int[] a = new int[t];
        for (int i = 0; i < t; i++)
        {
            a[i] = int.Parse(input2[i]);
        }


        int totalTrips = 0;
        for (int i = 0; i < t; i++)
        {
            totalTrips += (int)Math.Ceiling((double)a[i] / v);
        }


        int minTrips = 0;
        Queue<int> earth = new Queue<int>();
        for (int i = 0; i < t; i++)
        {
            earth.Enqueue(a[i]);
        }

        while (earth.Count > 0)
        {
            int currentSum = 0;
            while (earth.Count > 0 && currentSum + earth.Peek() <= v)
            {
                currentSum += earth.Dequeue();
                if (earth.Count == 0)
                {
                    minTrips++;
                    break;
                }
            }
            if (earth.Count > 0)
            {
                minTrips++;
            }

        }


        Console.WriteLine(totalTrips - minTrips);
    }
}