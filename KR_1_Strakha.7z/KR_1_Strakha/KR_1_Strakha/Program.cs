﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        var inputs = Console.ReadLine().Split().Select(int.Parse).ToArray();
        int n = inputs[0];
        int v0 = inputs[1];

        var days = Console.ReadLine().Split().Select(int.Parse).ToArray();

        int res = 0;

        foreach (var v in days)
        {
            if (v > 0)
            {
                if (v <= v0 / 2)
                {
                    res += 1;
                }
                else
                {
                    res += 1;
                    int remainingVolume = v - v0 / 2;
                    res += (int)Math.Ceiling((double)remainingVolume / v0);
                }
            }
        }

        Console.WriteLine(res);
    }
}