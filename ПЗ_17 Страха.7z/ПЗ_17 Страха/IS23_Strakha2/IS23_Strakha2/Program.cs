﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string[] colors = { "red", "green", "black", "white", "blue" };
        using (StreamWriter writer = new StreamWriter("\\\\192.168.10.6\\учебные кабинеты\\Кабинет 28\\2024 - 2025\\ОП 04 Основы алгоритмизации и программирования\\1-й семестр\\ИС-23К. Отчёты\\ПЗ17\\ПЗ_17 Сорокин\\IS23_Sorokin2\\colors.txt"))
        {
            foreach (string color in colors)
            {
                writer.WriteLine(color);
            }
        }
    }
}