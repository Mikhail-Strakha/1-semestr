﻿using System;
using System.IO;
class Program
{
    static void Main(string[] args)
    {
        string numbers = string.Empty;
        for (int i = 1; i <= 500; i++)
        {
            numbers += i.ToString() + ",";
        }
        numbers = numbers.TrimEnd(',');
        File.WriteAllText("\\\\192.168.10.6\\учебные кабинеты\\Кабинет 28\\2024 - 2025\\ОП 04 Основы алгоритмизации и программирования\\1-й семестр\\ИС-23К. Отчёты\\ПЗ17\\ПЗ_17 Сорокин\\IS23_Sorokin1\\numbers.txt", numbers);
    }
}
