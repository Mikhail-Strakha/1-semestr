﻿using System;

class Program
{
    static void Main()
    {
        double x = 9;

        double result = (2 * Math.Pow(x, 2)) - (3 * Math.Round(Math.Sign(x) * Math.Pow(Math.Abs(x), 1d / 3.0), 2));

        Console.WriteLine($"Результат: {result}");
    }
}