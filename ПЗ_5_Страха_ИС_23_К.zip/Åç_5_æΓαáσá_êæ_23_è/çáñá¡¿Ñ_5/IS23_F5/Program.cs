﻿using System;

class Program
{
    static void Main()
    {
        double x = 2;
        double y = 5;

        // Вычисление значения выражения (проверка деления на ноль)


        double result = (x - y) / (1 + x * y);

        Console.WriteLine($"Результат: {result}");
    }
}