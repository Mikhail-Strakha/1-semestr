﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите длину стороны a:");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine("Введите длину стороны b:");
        double b = Convert.ToDouble(Console.ReadLine());

        double cSquared = (a * a) + (b * b);

        double c = Math.Sqrt(cSquared);

        Console.WriteLine($"Для треугольника со сторонами {a} и {b}, гипотенуза равна: {c}");
    }
}