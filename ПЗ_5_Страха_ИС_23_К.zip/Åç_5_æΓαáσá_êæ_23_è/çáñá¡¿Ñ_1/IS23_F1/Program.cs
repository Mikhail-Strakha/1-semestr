﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите первое целое число:");
        int number1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Введите второе целое число:");
        int number2 = Convert.ToInt32(Console.ReadLine());

        int maxNumber = Math.Max(number1, number2);

        Console.WriteLine($"Наибольшее число: {maxNumber}");
    }
}