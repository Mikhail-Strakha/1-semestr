﻿using System;

class Program
{
    static void Main()
    {
        double x = 4;

        // Вычисление значения выражения (проверка деления на ноль)
        double denominator = 6 - (15 * x);

        if (denominator == 0)
        {
            Console.WriteLine("Ошибка: Деление на ноль.");
            return;
        }

        double result = (5 * Math.Pow(x, 2) - 12 * x + 4) / denominator;

        Console.WriteLine($"Результат: {result}");
    }
}